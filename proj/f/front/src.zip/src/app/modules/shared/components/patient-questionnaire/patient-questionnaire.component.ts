import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-questionnaire',
  templateUrl: './patient-questionnaire.component.html',
  styleUrls: ['./patient-questionnaire.component.scss']
})
export class PatientQuestionnaireComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
