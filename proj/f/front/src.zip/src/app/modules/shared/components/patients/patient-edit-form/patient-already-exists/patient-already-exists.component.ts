import { Component, Input, OnInit } from '@angular/core';
import { PatientManageModel } from 'src/app/core/models/user-management';
import { FormBuilder, Validators } from '@angular/forms';
import { formatDate } from '@fullcalendar/core';
import { getDateFromCalendar } from 'src/app/core/util/get-date-from-calendar';

@Component({
  selector: 'app-patient-already-exists',
  templateUrl: './patient-already-exists.component.html',
  styleUrls: ['./patient-already-exists.component.scss']
})
export class PatientAlreadyExistsComponent implements OnInit {
  constructor(private fb: FormBuilder) { 
    
  }

  ngOnInit(): void {
  }

  @Input() isOpen1: boolean;

  @Input() public set modelExists(item: PatientManageModel) {
    if (item){
      this.editFormExists.patchValue(item);
      // this.editFormExists.disable();
      this.editFormExists.controls['birthDate'].disable();
    }
  }

  public editFormExists = this.fb.group({
    id: this.fb.control(0, Validators.required),
    firstName: this.fb.control('', Validators.required),
    lastName: this.fb.control('', Validators.required),
    patronymic: this.fb.control(''),
    gender: this.fb.control(0),
    patientAgeType: this.fb.control(0),
    email: this.fb.control(''),
    phoneNumber: this.fb.control('', Validators.required),
    birthDate: this.fb.control(new Date(), Validators.required),
    cityId: this.fb.control(0, Validators.required),
    addressLine1: this.fb.control(''),
    addressLine2: this.fb.control(''),
  });

}
