import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reception-dashboard',
  templateUrl: './reception-dashboard.component.html',
  styleUrls: ['./reception-dashboard.component.scss']
})
export class ReceptionDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
