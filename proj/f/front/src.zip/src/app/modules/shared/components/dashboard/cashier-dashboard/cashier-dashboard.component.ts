import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cashier-dashboard',
  templateUrl: './cashier-dashboard.component.html',
  styleUrls: ['./cashier-dashboard.component.scss']
})
export class CashierDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
