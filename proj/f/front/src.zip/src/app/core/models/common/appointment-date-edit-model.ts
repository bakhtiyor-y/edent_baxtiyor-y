export interface AppointmentDateEditModel {
    id: number;
    appointmentDate: Date;
    partnerId?: number;
    dentalChairId?: number; 
}
