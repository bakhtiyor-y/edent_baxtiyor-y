export interface DentalChairModel {
    id: number;
    name: string;
    code: string;
}
