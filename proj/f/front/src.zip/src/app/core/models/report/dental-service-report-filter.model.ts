export interface DentalServiceReportFilter {
    from: Date;
    to: Date;
    id: number;
}