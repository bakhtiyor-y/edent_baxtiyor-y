export interface DateFilter {
    from: Date;
    to: Date;
}