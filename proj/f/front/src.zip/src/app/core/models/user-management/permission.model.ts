export interface PermissionModel {
    id: number;
    name: string;
}
