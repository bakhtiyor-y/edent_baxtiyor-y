import { TermType } from '../../enums';

export interface TermModel {
    id: number;
    name: string;
    type: TermType;
}
