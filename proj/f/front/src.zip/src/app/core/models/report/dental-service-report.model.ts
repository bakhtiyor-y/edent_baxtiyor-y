import { DentalServiceReportItem } from "./dental-service-report-item.model";

export interface DentalServiceReport {
    items: DentalServiceReportItem[];
}
