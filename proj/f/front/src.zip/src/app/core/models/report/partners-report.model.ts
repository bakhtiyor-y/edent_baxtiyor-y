import { PartnersReportItem } from "./partners-report-item.model";

export interface PartnersReport {
    items: PartnersReportItem[];
}
