export interface DentalServiceReportItem {
    name: string;
    id: number;
    providedCount: number;
    totalSumm: number;
}