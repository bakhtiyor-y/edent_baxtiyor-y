export interface DoctorReceptReportFilter {
    from: Date;
    to: Date;
}