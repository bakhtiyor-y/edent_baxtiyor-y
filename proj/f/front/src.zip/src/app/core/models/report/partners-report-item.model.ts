export interface PartnersReportItem {
    id: number;
    partnerName: string;
    incomeSumm: number;
    partnerSumm: number;
    calculatedSumm: number;
    leftSumm: number;
}
