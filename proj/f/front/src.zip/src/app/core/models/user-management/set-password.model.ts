export interface SetPasswordModel {
    password: string;
    confirmPassword: string;
    userId: number;
}
