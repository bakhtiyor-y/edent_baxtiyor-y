export interface ChangePasswordModel {
    currentPassword: string;
    newPassword: string;
    confirmNewPassword: string;
}
