export interface LoginModel {
    userName: string;
    password: string;
}
