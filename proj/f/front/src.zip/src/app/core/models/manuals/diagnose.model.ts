export interface DiagnoseModel {
    id: number;
    name: string;
    description: string;
}
