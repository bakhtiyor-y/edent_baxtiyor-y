export interface ReceptReportFilter {
    from: Date;
    to: Date;
}