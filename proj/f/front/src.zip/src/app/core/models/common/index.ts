export * from './appointment.model';
export * from './schedule-event.model';
export * from './appointment-manage.model';
export * from './appointment-date-edit-model';
export * from './treatment.model';
export * from './recept.model';
export * from './treatment-dental-service.model';
export * from './recept-inventory.model';
export * from './invoice.model';
export * from './payment.model';
export * from './discount.model';
export * from './inventory-outcome.model';
export * from './inventory-outcome-item.model';
export * from './inventory-income.model';
export * from './inventory-income-item.model'; 
export * from './doctor-schedule.model';
export * from './patient-tooth.model';
export * from './recept-dental-service.model';
export * from './appointment-manage-with-last.model';


