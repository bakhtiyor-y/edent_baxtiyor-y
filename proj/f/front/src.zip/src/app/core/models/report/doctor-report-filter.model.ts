export interface DoctorReportFilter {
    from: Date;
    to: Date;
}
