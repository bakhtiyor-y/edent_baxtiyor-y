export interface CountryModel {
    id: number;
    name: string;
    code: string;
}
