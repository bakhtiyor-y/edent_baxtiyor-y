export interface PartnersReportFilter {
    from: Date;
    to: Date;
}