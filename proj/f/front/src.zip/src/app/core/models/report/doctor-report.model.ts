import { DoctorReportItem } from './doctor-report-item.model';

export interface DoctorReport {
    items: DoctorReportItem[];
}
