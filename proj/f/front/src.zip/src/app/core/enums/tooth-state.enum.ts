export enum ToothState {
    Healthy = 0,
    Sealed = 1,
    Depulpated = 2,
    Extracted = 3,
    Implanted = 4,
    Crowned = 5
}