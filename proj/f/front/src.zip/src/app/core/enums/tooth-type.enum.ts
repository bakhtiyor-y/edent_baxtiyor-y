export enum ToothType {
    Adult = 0,
    Child = 1
}