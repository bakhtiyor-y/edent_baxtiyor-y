export enum PatientAgeType {
    Adult = 0,
    Child = 1,
    Baby = 2
}