export enum ProfitType {
    Percent = 1,
    Fixed = 2
}
