export enum DentalServiceType {
    Common,
    Treatment,
    Additional
}
