export enum PaymentType {
    Cash = 0,
    Card = 1,
    Bank = 2
}
