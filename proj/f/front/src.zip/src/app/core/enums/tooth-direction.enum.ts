export enum ToothDirection {
    Default = 0,
    TopRight = 1,
    TopLeft = 2,
    BottomRight = 3,
    BottomLeft = 4
}
