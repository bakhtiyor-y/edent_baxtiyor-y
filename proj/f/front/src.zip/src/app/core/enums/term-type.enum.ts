export enum TermType {
    Percent = 1,
    Rent = 2,
    Fixed = 3
}
