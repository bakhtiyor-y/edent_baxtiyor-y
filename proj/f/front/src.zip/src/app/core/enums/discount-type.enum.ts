export enum DiscountType {
    Fixed = 0,
    Percent = 1
}
