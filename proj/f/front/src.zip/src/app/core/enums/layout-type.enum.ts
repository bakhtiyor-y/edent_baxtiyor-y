export enum LayoutType {
    Admin,
    Doctor,
    Reception,
    Cashier,
    Main,
    Rentgen
}
